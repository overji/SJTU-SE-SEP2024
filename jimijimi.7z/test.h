#ifndef TEST_H
#define TEST_H

#include <QString>

class Test {
public:
    Test();
    int testFromFile(QString inputFile, QString outputFile);
};

#endif // TEST_H

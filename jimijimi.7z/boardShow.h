//
// Created by overji on 2024/12/28.
//

#ifndef SEP2024_TEMPLATE_BOARDSHOW_H
#define SEP2024_TEMPLATE_BOARDSHOW_H
#include <QWidget>
#include "state.h"
#include <QPainter>

class boardShow :public QWidget
{
    Q_OBJECT
public:
    boardShow(State * state);
    void paintEvent(QPaintEvent *event) override;
    void drawMap(QPainter & painter);
    State * mystate;
    QVector<QColor>colors;
    double xScaleRatio;
    double yScaleRatio;
    bool isBuild;
};

#endif //SEP2024_TEMPLATE_BOARDSHOW_H

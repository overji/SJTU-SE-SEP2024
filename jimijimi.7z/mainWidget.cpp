//
// Created by overji on 2024/12/28.
//

#include "mainWidget.h"
#include <QFileDialog>
#include <QHBoxLayout>
#include <QPushButton>
#include <QWidget>
#include <QPushButton>
#include <QPainter>
#include <QKeyEvent>
#include <QTimer>
#include "state.h"
#include <QMessageBox>


mainWidget::mainWidget() {
    this->layout = new QHBoxLayout();
    this->button = new QPushButton("load");
    this->layout->addWidget(button,1);
    connect(this->button,&QPushButton::clicked,this,[=](){
        this->loadFileDialog();
    });
    this->state = new State();
    this->shower = new boardShow(this->state);
    this->layout->addWidget(this->shower,3);
    S = 0;
    N = 0;
    this->setLayout(this->layout);
}

void mainWidget::loadFileDialog()
{
    QString filePath = QFileDialog::getOpenFileName(this, tr("Open Input File"), R"(C:\Users\overji\Desktop\code2\sepTests\sep2024)", tr("Input Files: (*.*)"));
    this->state->readFromFile(filePath);
}

void mainWidget::keyPressEvent(QKeyEvent *event) {
    switch (event->key()) {
    case Qt::Key_S:
        this->state->applyStep();
        break;
    case Qt::Key_R:
        QMessageBox::warning(this,"得分",QString::fromStdString("Points: ") + QString::number(this->state->curScore));
        break;
    default:
        break;
    }
}

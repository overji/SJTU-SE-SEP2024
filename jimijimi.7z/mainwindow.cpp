#include "mainwindow.h"
#include "mainWidget.h"
#include <QTimer>

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent)
{
    this->wid = new mainWidget();
    this->setCentralWidget(wid);
    this->setFixedSize(800,600);
    //初始化计时器，remainTimeInput:剩余时间
    QTimer *gameFlashTimer = new QTimer(this);
    //将计时器的超时事件与LinkGame的update函数绑定，即一旦计时器时间到了，就会调用一次update函数
    connect(gameFlashTimer, &QTimer::timeout, this, QOverload<>::of(&MainWindow::update));
    int gameFps = 60;
    int gameFlashMs = 1000 / gameFps; //每秒刷新gameFps次
    gameFlashTimer->start(gameFlashMs); //计时器开始计时
}

MainWindow::~MainWindow() {}

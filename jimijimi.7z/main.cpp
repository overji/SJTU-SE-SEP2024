#include <QApplication>

#include "mainwindow.h"
#include "test.h"

int main(int argc, char *argv[]) {
    QApplication a(argc, argv);
    MainWindow w;
    //完成实现后，可以将inputfile和outputfile替换成相应文件进行测试
    Test test;
    test.testFromFile(SOURCE_DIR "/input/input1.txt", SOURCE_DIR "/input/output1.txt");
    test.testFromFile(SOURCE_DIR "/input/input2.txt", SOURCE_DIR "/input/output2.txt");
    test.testFromFile(SOURCE_DIR "/input/input3.txt", SOURCE_DIR "/input/output3.txt");
    test.testFromFile(SOURCE_DIR "/input/input4.txt", SOURCE_DIR "/input/output4.txt");
    test.testFromFile(SOURCE_DIR "/input/input5.txt", SOURCE_DIR "/input/output5.txt");

    w.show();
    return a.exec();
}

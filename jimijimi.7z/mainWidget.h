//
// Created by overji on 2024/12/28.
//

#ifndef SEP2024_TEMPLATE_MAINWIDGET_H
#define SEP2024_TEMPLATE_MAINWIDGET_H
#include <QHBoxLayout>
#include <QPushButton>
#include <QWidget>
#include "state.h"
#include "boardShow.h"

class mainWidget:public QWidget
{
    Q_OBJECT
public:
    mainWidget();
    QHBoxLayout * layout;
    QPushButton * button;
    boardShow * shower;
    State * state;
    void keyPressEvent(QKeyEvent *event) override;
    int S;
    int N;
public slots:
    void loadFileDialog();
};

#endif //SEP2024_TEMPLATE_MAINWIDGET_H

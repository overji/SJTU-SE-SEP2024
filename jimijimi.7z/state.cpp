#include "state.h"

#include <QFile>
#include <QWidget>
#include <cstdio>



int State::getV(int i, int j) {
    if (i < 0 || j < 0 || i >= n || j >= n) {
        return -1;
    }
    return board[i][j];
}



int State::applySteps() {
    //TODO: 请在此添加你的代码
    int ans = 0;
    while(!this->steps.empty())
    {
        ans += applyStep();
    }
    return ans;
}

void State::readFromFile(QString fileName) {
    //TODO: 请在此添加你的代码
    this->clearAll();
    isBuild = true;
    QFile file(fileName);
    if(! file.open(QIODevice::ReadOnly | QIODevice::Text)){
        return;
    }
    QTextStream textStream(&file);
    textStream >> this->n;
    textStream >> this->left;
    this->board.clear();
    this->steps.clear();
    this->board = QVector<QVector<int>>(n);
    this->steps = QVector<QPair<int, int>>(left);
    for(int r = 0;r < n;r ++)
    {
        this->board[r] = QVector<int>(n);
    }
    for(int r = n - 1;r >= 0;r --)
    {
        for(int c = 0;c < n;c ++)
        {
            textStream >> this->board[r][c];
        }
    }
    for(int i = 0;i < left;i ++)
    {
        textStream >> this->steps[i].first >> this->steps[i].second;
    }
}

int State::getN() {
    return this->n;
}

int State::getLeft() {
    return this->left;
}

QVector<QVector<int>> State::getBoard() {
    return this->board;
}

State::State()
{
    isBuild = false;
    this->curScore = 0;
}

int State::clearConj()
{
    if(!isBuild)
    {
        return 0;
    }
    int score = 0;
    for(int r = 0;r < n;r ++)
    {
        for(int c = n-1;c >= 0;c --)
        {
            if(board[r][c] == 0)
            {
                continue;
            }
            int cnt = clearRowCol(r,c);
            if(cnt != 0)
            {
                score += 3 + (cnt - 3) * 2;
            }
        }
    }
    return score;
}

int State::clearRowCol(int r, int c) {
    int ans = 0;
    int target = board[r][c];
    QVector<QPair<int,int>>row;
    QVector<QPair<int,int>>col;
    row.push_back({r,c});
    col.push_back({r,c});
    //check row and col
    for(int s = c;s >= 0;s --)
    {
        if(s == c)
        {
            continue;
        }
        if(board[r][s] != target)
        {
            break;
        }
        else
        {
            col.push_back({r,s});
        }
    }
    for(int s = c;s < n;s ++)
    {
        if(s == c)
        {
            continue;
        }
        if(board[r][s] != target)
        {
            break;
        }
        else
        {
            col.push_back({r,s});
        }
    }
    for(int nowr = r;nowr < n;nowr ++)
    {
        if(nowr == r)
        {
            continue;
        }
        if(board[nowr][c] != target)
        {
            break;
        }
        else
        {
            row.push_back({nowr,c});
        }
    }
    for(int nowr = r;nowr >= 0;nowr --)
    {
        if(nowr == r)
        {
            continue;
        }
        if(board[nowr][c] != target)
        {
            break;
        }
        else
        {
            row.push_back({nowr,c});
        }
    }
    if(row.size() >= 3)
    {
        for(auto pr:row)
        {
            if(board[pr.first][pr.second] != 0)
            {
                ans ++;
            }
            board[pr.first][pr.second] = 0;
        }
    }
    if(col.size() >= 3)
    {
        for(auto pr:col)
        {
            if(board[pr.first][pr.second] != 0)
            {
                ans ++;
            }
            board[pr.first][pr.second] = 0;
        }
    }
    return ans;
}

int State::checkFalling()
{
    int cnt = 1;
    while(cnt)
    {
        cnt = 0;
        for(int r = n-1;r >= 0;r --)
        {
            for(int c = 0;c < n;c ++)
            {
                if(getV(r,c) > 0 && getV(r - 1,c) == 0)
                {
                    int tmp = this->board[r][c];
                    this->board[r][c] = 0;
                    this->board[r-1][c] = tmp;
                    cnt ++;
                }
            }
        }
    }
    return 0;
}

int State::applyStep()
{
    int totalScore = 0;
    int curS = 0;
    if(this->steps.empty())
    {
        return 0;
    }
    auto pr = this->steps[0];
    this->steps.pop_front();
    int tmp = getV(pr.first,pr.second);
    if(tmp < 0)
    {
        return 0;
    }
    if(getV(pr.first,pr.second + 1) < 0)
    {
        return 0;
    }
    this->board[pr.first][pr.second] = this->board[pr.first][pr.second + 1];
    this->board[pr.first][pr.second + 1] = tmp;
    checkFalling();
    while((curS = this->clearConj()) != 0)
    {
        totalScore += curS;
        checkFalling();
    }
    checkFalling();
    this->curScore += totalScore;
    return totalScore;
}

void State::clearAll()
{
    this->curScore = 0;
}

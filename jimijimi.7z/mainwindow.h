#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "mainWidget.h"

class MainWindow: public QMainWindow {
    Q_OBJECT
private:
    mainWidget * wid;
public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
};
#endif // MAINWINDOW_H

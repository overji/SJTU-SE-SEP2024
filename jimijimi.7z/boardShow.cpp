//
// Created by overji on 2024/12/28.
//

#include "boardShow.h"

boardShow::boardShow(State * state)
{
    this->mystate = state;
    colors.push_back(QColor("red"));
    colors.push_back(QColor("yellow"));
    colors.push_back(QColor("blue"));
    colors.push_back(QColor("green"));
    colors.push_back(QColor(qRgb(15,255,175)));
    colors.push_back(QColor(qRgb(195,15,165)));
    colors.push_back(QColor(qRgb(115,0,115)));
    colors.push_back(QColor(qRgb(215,0,5)));
    colors.push_back(QColor(qRgb(215,177,5)));
}

void boardShow::paintEvent(QPaintEvent *event) {
    if(!mystate->isBuild)
    {
        return;
    }
    QPainter painter(this); //创建一个QPainter对象
    painter.setRenderHint(QPainter::Antialiasing); //设置抗锯齿
    //设置坐标变换，变换大小便于后续绘图
    QSize size = this->size();
    this->xScaleRatio = size.width() / 600.0;
    this->yScaleRatio = size.height() / 600.0;
    painter.scale(xScaleRatio, yScaleRatio);
    this->drawMap(painter);
}

void boardShow::drawMap(QPainter &painter)
{
    int N = mystate->getN();
    int width = 600/N;
    int height = 600/N;
    int outWidth = width / 20;
    int outHeight = width / 20;
    auto board = mystate->getBoard();
    QColor boarderColor = QColor("black");
    for(int r = 0;r < N;r ++)
    {
        for(int c = 0;c < N;c ++)
        {
            int leftTopX = c * width;
            int leftTopY = (N - 1 - r) * width;
            QColor color = colors[board[r][c] % colors.size()];
            QPoint Boarders[4] = {
                QPoint(leftTopX,leftTopY),
                QPoint(leftTopX+width,leftTopY),
                QPoint(leftTopX+width,leftTopY+height),
                QPoint(leftTopX,leftTopY+height)
            };
            QPoint InnerBox[4] = {
                QPoint(leftTopX + outWidth,leftTopY + outHeight),
                QPoint(leftTopX+width - outWidth,leftTopY + outHeight),
                QPoint(leftTopX+width - outWidth,leftTopY+height - outHeight),
                QPoint(leftTopX + outWidth,leftTopY+height - outHeight)
            };
            //绘制箱子
            QPen pen;
            pen.setColor(boarderColor);
            pen.setWidth(outWidth);
            pen.setJoinStyle(Qt::MiterJoin);
            painter.save();
            painter.setPen(boarderColor);
            //绘制箱子含有边框的矩形
            painter.drawConvexPolygon(Boarders,4);
            //绘制箱子内部不含边框的矩形，以此达到绘制边框的效果
            if(board[r][c] != 0)
            {
                painter.setBrush(color);
            }
            else
            {
                painter.setBrush(Qt::NoBrush);
            }
            painter.drawConvexPolygon(InnerBox,4);
            painter.setPen(Qt::black);
            if(board[r][c] != 0)
            {
                painter.setFont(QFont("Arial", 20));
                painter.drawText(QRect(leftTopX + outWidth,leftTopY + outHeight,width - 2*outWidth,height - 2*outHeight),Qt::AlignCenter, QString::number(board[r][c]));
            }
            painter.restore();
        }
    }
}
